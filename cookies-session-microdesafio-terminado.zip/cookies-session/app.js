const express = require("express");

const app = express();
const mainRouter = require("./routes/main.routes");
const session = require("express-session");

//configuraciones
app.set("view engine", "ejs");

app.use(express.urlencoded({ extended: false }));

app.use(session({ secret: "lo que quieras" }));
// rutas
app.use(mainRouter);

app.listen(3000, () => {
  console.log("Aplicacion corriendo en el puerto 3000");
});
