const { validationResult } = require("express-validator");

const mainController = {
  index: (req, res) => {
    res.render("index");
  },
  create: (req, res) => {
    console.log(req.body);

    const errores = validationResult(req);

    req.session.color = req.body.color;

    res.render("index", { usuario: req.body, errores: errores.errors });
  },
  perfil: (req, res) => {
    const color = req.session.color;
    res.render("perfil", { color: color });
  },
  olvidar: (req, res) => {
    const color = req.session.color;
    res.render("perfil", { color: color });
  },
};

module.exports = mainController;
