const express = require("express");
const mainController = require("../controllers/main.controller");

/////////////////////////////////////////////////
const { body } = require("express-validator");

const userValidation = [
  body("nombre")
    .notEmpty()
    .withMessage("El nombre es obligatorio")
    .bail()
    .isLength({ min: 3 })
    .withMessage("El nombre es muy corto"),
  body("edad")
    .notEmpty()
    .withMessage("La edad es obligatoria")
    .bail()
    .isInt()
    .withMessage("Tiene que ser un numero"),
  body("email")
    .notEmpty()
    .withMessage("El email es obligatorio")
    .bail()
    .isEmail()
    .withMessage("Ingrese un email valido"),
];

////////////////////////////////////////////////

const router = express.Router();

router.get("/", mainController.index);
router.post("/", userValidation, mainController.create);
router.get("/perfil", mainController.perfil);

module.exports = router;
