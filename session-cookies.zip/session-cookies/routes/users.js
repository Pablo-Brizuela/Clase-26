var express = require('express');
const userController = require('../controllers/user.controller');
var router = express.Router();

/* GET users listing. */
router.get('/', userController.loginView );
router.post('/', userController.loginAction);

router.get('/logout', userController.logoutAction );

router.get('/register', userController.registerView);
router.post('/register', userController.loginAction);

router.get('/main', userController.mainView);
router.get('/perfil', userController.perfilView);


module.exports = router;
