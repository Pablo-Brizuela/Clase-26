const userController = {
  loginView: (req, res) => {
    res.render("user-login");
  },

  loginAction: (req, res) => {
    const user = req.body;

    req.session.user = user;

    res.cookie("userEmail", user.email, { maxAge: 1000 * 60 * 10 });

    res.redirect("/users/perfil");
  },

  perfilView: (req, res) => {
    if (req.session.user) {
      console.log(req.session.user);

      res.render("user-perfil", { user: req.session.user });
    }

    res.redirect("/users");
  },

  logoutAction: (req, res) => {
    res.clearCookie("userEmail");
    req.session.destroy();
    res.redirect("/users");
  },

  ///////////////////////////////////////////////
  registerView: (req, res) => {
    res.render("user-register");
  },

  registerAction: (req, res) => {
    res.redirect("/users");
  },

  mainView: (req, res) => {
    res.redirect("/users");
  },
};

module.exports = userController;
